# -*- coding: utf-8 -*-

from . import inherit_account_journal