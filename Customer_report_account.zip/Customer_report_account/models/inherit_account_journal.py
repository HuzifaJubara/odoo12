from odoo import models, fields, api


class account(models.Model):

    _inherit = "account.journal"


