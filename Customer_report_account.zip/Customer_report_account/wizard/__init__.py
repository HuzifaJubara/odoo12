# -*- coding: utf-8 -*-

from . import partner_credit_note
from . import product_credit_note
