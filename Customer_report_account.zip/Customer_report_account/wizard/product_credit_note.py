# -*- coding: utf-8 -*-
###########

from odoo import api, fields, models, _
import xlsxwriter
import base64
import datetime
from io import StringIO, BytesIO
from datetime import *
from datetime import datetime, timedelta
from odoo.exceptions import UserError
from dateutil import relativedelta


class WizardProductCreditNote(models.Model):
    _name = 'wizard.product.credit.note'
    _description = 'Print Product Credit Note'
    product_id = fields.Many2one('product.product', string='Product')
    from_date = fields.Date(string='Date From', required=True,
                            default=str(datetime.now() + relativedelta.relativedelta(days=-30))[:10])
    to_date = fields.Date(string='Date To', required=True, default=fields.Date.today())

    def print_report(self):
        for report in self:
            product_id = report.product_id
            to_date = report.to_date
            from_date = report.from_date
            report.name = 'Credit Note By Product'
            file_name = _('Product Credit Note.xlsx')
            fp = BytesIO()
            workbook = xlsxwriter.Workbook(fp)
            excel_sheet = workbook.add_worksheet('Product Credit Note')
            header_format = workbook.add_format(
                {'bold': True, 'font_color': 'black', 'bg_color': 'white', 'border': 1})
            header_format_sequence = workbook.add_format(
                {'bold': False, 'font_color': 'black', 'bg_color': 'white', 'border': 1})
            format = workbook.add_format({'bold': False, 'font_color': 'black', 'bg_color': 'white', 'border': 1})
            title_format = workbook.add_format({'bold': True, 'font_color': 'black', 'bg_color': 'white'})
            title_format.set_align('center')
            format.set_align('center')
            header_format_sequence.set_align('center')
            header_format.set_align('center')
            header_format.set_text_wrap()
            format.set_text_wrap()
            format.set_num_format('#,##0.00')
            format_details = workbook.add_format()
            format_details.set_num_format('#,##0.00')
            col = 0
            row = 0
            first_row = 1
            excel_sheet.set_column(col, col + 20, 20)
            excel_sheet.write(row, col, 'Product', header_format)
            col += 1
            excel_sheet.write(row, col, 'Total Invoice', header_format)
            col += 1
            excel_sheet.write(row, col, 'Total Credit Note', header_format)
            col += 1
            excel_sheet.write(row, col, '%', header_format)
            col += 1
            row += 1
            col = 0
            if product_id:
                out_invoice = report.env['account.invoice'].search(
                    [('date_invoice', '<=', to_date), ('date_invoice', '>=', from_date), ('type', '=', 'out_invoice'),
                     ('invoice_line_ids.product_id', '=', product_id.id), ('state', '=', 'paid')])
                for inv in out_invoice:
                    out_refund = report.env['account.invoice'].search(
                        [('type', '=', 'out_refund'), ('refund_invoice_id', '=', inv.id), ('state', '=', 'paid')])
                    if out_refund:
                        for invoice in out_refund:
                            for line in invoice.invoice_line_ids:
                                product_id = line.product_id.name
                                out_invoice_quantity = inv.amount_total
                                excel_sheet.write(row, col, product_id, format)
                                col += 1
                                excel_sheet.write(row, col, out_invoice_quantity, format)
                                col += 1
                                out_refund_quantity = invoice.amount_total
                                percentage = (out_refund_quantity / out_invoice_quantity) * 100
                                if out_refund_quantity:
                                    excel_sheet.write(row, col, out_refund_quantity, format)
                                else:
                                    excel_sheet.write(row, col, 0.0, format)
                                col += 1
                                excel_sheet.write(row, col, percentage, format)
                                col += 1
                                row += 1
                                col = 0
                    else:
                        for line in inv.invoice_line_ids:
                            product_id = line.product_id.name
                            out_invoice_quantity = inv.amount_total
                            out_refund_quantity = 0.0
                            excel_sheet.write(row, col, product_id, format)
                            col += 1
                            excel_sheet.write(row, col, out_invoice_quantity, format)
                            col += 1
                            percentage = (out_refund_quantity / out_invoice_quantity) * 100
                            excel_sheet.write(row, col, out_refund_quantity, format)
                            col += 1
                            excel_sheet.write(row, col, percentage, format)
                            col += 1
                            row += 1
                            col = 0
            else:
                out_invoice = report.env['account.invoice'].search(
                    [('date_invoice', '<=', to_date), ('date_invoice', '>=', from_date), ('type', '=', 'out_invoice'),
                     ('state', '=', 'paid')])
                for inv in out_invoice:
                    out_refund = report.env['account.invoice'].search(
                        [('type', '=', 'out_refund'), ('refund_invoice_id', '=', inv.id), ('state', '=', 'paid')])
                    if out_refund:
                        for invoice in out_refund:
                            for line in invoice.invoice_line_ids:
                                product_id = line.product_id.name
                                out_invoice_quantity = inv.amount_total
                                excel_sheet.write(row, col, product_id, format)
                                col += 1
                                excel_sheet.write(row, col, out_invoice_quantity, format)
                                col += 1
                                out_refund_quantity = invoice.amount_total
                                percentage = (out_refund_quantity / out_invoice_quantity) * 100
                                if out_refund_quantity:
                                    excel_sheet.write(row, col, out_refund_quantity, format)
                                else:
                                    excel_sheet.write(row, col, 0.0, format)
                                col += 1
                                excel_sheet.write(row, col, percentage, format)
                                col += 1
                                row += 1
                                col = 0
                    else:
                        for line in inv.invoice_line_ids:
                            product_id = line.product_id.name
                            out_invoice_quantity = inv.amount_total
                            excel_sheet.write(row, col, product_id, format)
                            col += 1
                            excel_sheet.write(row, col, out_invoice_quantity, format)
                            col += 1
                            out_refund_quantity = 0.0
                            percentage = (out_refund_quantity / out_invoice_quantity) * 100
                            excel_sheet.write(row, col, out_refund_quantity, format)
                            col += 1
                            excel_sheet.write(row, col, percentage, format)
                            col += 1
                            row += 1
                            col = 0
            col = 0
            excel_sheet.write(row, col, 'Total', header_format)
            excel_sheet.write_formula(row, col + 1, 'SUM(B' + str(first_row) + ':B' + str(row) + ')', header_format)
            excel_sheet.write_formula(row, col + 2, 'SUM(C' + str(first_row) + ':C' + str(row) + ')', header_format)
            workbook.close()
            file_download = base64.b64encode(fp.getvalue())
            fp.close()
            wizardmodel = self.env['product.credit.note.report.excel']
            res_id = wizardmodel.create({'name': file_name, 'file_download': file_download})
            return {
                'name': 'Files to Download',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'product.credit.note.report.excel',
                'type': 'ir.actions.act_window',
                'target': 'new',
                'res_id': res_id.id,
            }

    ############################################


class product_credit_note_report_excel(models.TransientModel):
    _name = 'product.credit.note.report.excel'

    name = fields.Char('File Name', size=256, readonly=True)
    file_download = fields.Binary('File to Download', readonly=True)
